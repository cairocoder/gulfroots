<?php

use Illuminate\Database\Seeder;
use Ramsey\Uuid\Uuid;

class PostsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $faker = Faker\Factory::create();
        //
        for($i = 1; $i <= 500; $i++) {
            $search_sentence = " جميع الاعلانات";
            $post = App\Posts::create([
                'title' => $faker->realText(20),
                'short_des' => $faker->realText(20),
                'long_des' => $faker->realText(200),
                'detailed_address' => $faker->address,
                'seller_name' => $faker->name,
                'seller_email' => $faker->email,
                'seller_contact_no' => $faker->phoneNumber,
                'price' => $faker->numberBetween(1000,2500),
                'sub_category_id' => $faker->numberBetween(19,50),
                'user_id' => $faker->numberBetween(1,20),
                'isArchived' => $faker->numberBetween(0, 1),
                'isApproved' => $faker->numberBetween(0, 1),
                'isinTop' => $faker->numberBetween(0, 1),
                'search_sentence' => "",
            ]);
            for($j = 0; $j < 1; $j++){
                $filter = App\FiltersPosts::create(['filters_id' => $faker->numberBetween(1,5), 'posts_id' => $i]);
                $search_sentence .= ' ' . $filter->name;
                $filter = App\FiltersPosts::create(['filters_id' => $faker->numberBetween(15,16), 'posts_id' => $i]);
                $search_sentence .= ' ' . $filter->name;
                $filter = App\FiltersPosts::create(['filters_id' => $faker->numberBetween(11,12), 'posts_id' => $i]);
                $search_sentence .= ' ' . $filter->name;
                $filter = App\FiltersPosts::create(['filters_id' => $faker->numberBetween(13,14), 'posts_id' => $i]);
                $search_sentence .= ' ' . $filter->name;
            }
            $ancestor = App\Categories::findorfail($post->sub_category_id);
            $search_sentence .= ' ' . $ancestor->name;
            while($ancestor->sub_id != null){
                $ancestor = App\Categories::findorfail($ancestor->sub_id);
                $search_sentence .= ' ' . $ancestor->name;
            }
            //add post_features
            if($i % 2){
                for($j = 0; $j < 2; $j++){
                    $tmp = App\PostFeatures::create([
                        'type' => 5 + $faker->numberBetween(1,5),
                        'post_id' => $i,
                        'expiry_date' => $post->created_at->addDays($faker->numberBetween(7,30)),
                    ]);
                    App\FiltersPosts::create(['filters_id' => $tmp->type, 'posts_id' => $i]);
                    if($tmp->type == 7){
                        $search_sentence .= ' paid isinMain اعلانات مدفوعه مميزة';
                    }
                    if($tmp->type == 8){
                        $search_sentence .= ' isBreaking اعلانات مدفوعه عاجلة';
                    }
                    if($tmp->type == 9){
                        $search_sentence .= ' paid isColored اعلانات مدفوعه ملونة';
                    }
                    if($tmp->type == 10){
                        $search_sentence .= ' paid isinTop أفضل الاعلانات';
                    }
                }
            }
            //add post filters
            $post->search_sentence = $search_sentence;
            $post->save();
            if($post)
                $post->searchable();
            $hash = $this->pageId('posts', $post->id);
            DB::table('posts_dictionaries')->insert([
                'hash' => $hash,
                'post_id' => $post->id,
            ]);

            for($j = 0; $j < 10; $j++){
                DB::table('post__photos')->insert([
                    'photolink' => 'images/1512666410.png',
                    'post_id' => $i,
                ]);
            }
        }
    }
    private function pageId($identifier, $id = null)
    {
        $uuid5 = Uuid::uuid5(Uuid::NAMESPACE_DNS, $identifier);
        if ($id) {
            $uuid5 = Uuid::uuid5(Uuid::NAMESPACE_DNS, $identifier . '-' . $id);
        }
        return $uuid5;
    }
}
